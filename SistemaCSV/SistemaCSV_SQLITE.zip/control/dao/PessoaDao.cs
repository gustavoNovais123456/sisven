﻿using SistemaCSV.model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaCSV.control.dao
{
    class PessoaDao
    {
        public bool gravarPessoa(Pessoa pessoa)
        {
            return pessoa.Id > 0 ? atualizarPessoa(pessoa) : inserirPessoa(pessoa);
        }
        public bool inserirPessoa(Pessoa pessoa)
        {
            String SQL = "INSERT INTO pessoas (cpf,cnh,nome,celular,endereco,email,login,senha,tipo_pessoa,ativo)" +
                         "VALUES (@cpf,@cnh,@nome,@celular,@endereco,@email,@login,@senha,@tipo_pessoa,true)";

            SQLiteCommand cmd = Conn.Conexaobd().CreateCommand();

            try
            {
                cmd.CommandText = SQL;
                cmd.Parameters.AddWithValue("@cpf", pessoa.Cpf);
                cmd.Parameters.AddWithValue("@cnh", pessoa.Cnh);
                cmd.Parameters.AddWithValue("@nome", pessoa.Nome);
                cmd.Parameters.AddWithValue("@celular", pessoa.Telefone);
                cmd.Parameters.AddWithValue("@endereco", pessoa.Endereco);
                cmd.Parameters.AddWithValue("@email", pessoa.Email);
                cmd.Parameters.AddWithValue("@login", pessoa.Login);
                cmd.Parameters.AddWithValue("@senha", pessoa.Senha);
                cmd.Parameters.AddWithValue("@tipo_pessoa", pessoa.TipoPessoa);
                cmd.ExecuteNonQuery();
            }

            catch (Exception e)
            {
                return false;
                MessageBox.Show(e.Message);
            }
            finally
            {
                Conn.Conexaobd().Close();
            }

            return true;
        }

        private bool atualizarPessoa(Pessoa pessoa)
        {
            String SQL = @"UPDATE pessoas SET cpf = @cpf,cnh = @cnh,nome = @nome,celular = @celular,endereco = @endereco,email = @email,login = @login,senha = @senha,
                           tipo_pessoa = @tipo_pessoa,ativo = @ativo WHERE id = @id";

            try
            {
                using (var cmd = Conn.Conexaobd().CreateCommand())
                {
                    cmd.CommandText = SQL;
                    cmd.Parameters.AddWithValue("@cpf", pessoa.Cpf);
                    cmd.Parameters.AddWithValue("@cnh", pessoa.Cnh);
                    cmd.Parameters.AddWithValue("@nome", pessoa.Nome);
                    cmd.Parameters.AddWithValue("@celular", pessoa.Telefone);
                    cmd.Parameters.AddWithValue("@endereco", pessoa.Endereco);
                    cmd.Parameters.AddWithValue("@email", pessoa.Email);
                    cmd.Parameters.AddWithValue("@login", pessoa.Login);
                    cmd.Parameters.AddWithValue("@senha", pessoa.Senha);
                    cmd.Parameters.AddWithValue("@tipo_pessoa", pessoa.TipoPessoa);
                    cmd.Parameters.AddWithValue("@ativo", pessoa.Ativo);
                    cmd.Parameters.AddWithValue("@id", pessoa.Id);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception)
            {
                return false;
            }
            finally
            {
                Conn.Conexaobd().Dispose();
            }
            return true;
        }

        public void inativarPessoa(Pessoa pessoa)
        {
            string sql = "UPDATE pessoas SET ativo = @ativo WHERE id = @id";

            try
            {
                using (var cmd = Conn.Conexaobd().CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@ativo", pessoa.Ativo);
                    cmd.Parameters.AddWithValue("@id", pessoa.Id);
                    cmd.ExecuteNonQuery();
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            finally
            {
                Conn.Conexaobd().Close();
            }
        }

        #region pesquisas
        public DataTable pesquisaDePessoas(string filtro, string cond, string tipo)
        {
            string sql = @"select * from pessoas where lower(cpf||cnh||nome) like @filtro and
                        case when @ativos then ativo = 1 when @inativos then
                        ativo = 0 else true end and CASE WHEN @gerente THEN tipo_pessoa = 'gerente' WHEN @motorista THEN tipo_pessoa = 'motorista' else true END;";
            SQLiteDataAdapter da = null;
            DataTable dt = new DataTable();
            try
            {
                using (var cmd = Conn.Conexaobd().CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@filtro", "%" + filtro.ToLower() + "%");
                    cmd.Parameters.AddWithValue("@ativos", cond.ToLower().Equals("ativos"));
                    cmd.Parameters.AddWithValue("@inativos", cond.ToLower().Equals("inativos"));
                    cmd.Parameters.AddWithValue("@gerente", tipo.ToLower().Equals("gerente"));
                    cmd.Parameters.AddWithValue("@motorista", tipo.ToLower().Equals("motorista"));
                    da = new SQLiteDataAdapter(cmd);
                    da.Fill(dt);
                    return dt;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return null;
            }
        }
            public DataTable buscarLogin(string login, string senha)
        {

            string sql = @"select nome,login,senha,tipo_pessoa from pessoas where 
                            login = @login and senha = @senha and ativo = 1";

            SQLiteDataAdapter da = null;
            DataTable dt = new DataTable();
            try
            {
                using (var cmd = Conn.Conexaobd().CreateCommand())
                {
                    cmd.CommandText = sql;
                    cmd.Parameters.AddWithValue("@login", login.ToLower());
                    cmd.Parameters.AddWithValue("@senha", senha.ToLower());
                    da = new SQLiteDataAdapter(cmd);
                    da.Fill(dt);
                    return dt;
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return null;
            }

        }
        #endregion
    }
}
