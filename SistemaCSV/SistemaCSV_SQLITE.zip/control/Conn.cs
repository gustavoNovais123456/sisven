﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaCSV.control
{
    class Conn
    {
        private static SQLiteConnection sqliteConnection;

        public static SQLiteConnection Conexaobd()
        {
            sqliteConnection = new SQLiteConnection(@"Data Source=novoBD.db; Version=3;");
            sqliteConnection.Open();
            return sqliteConnection;
        }
    }
}
