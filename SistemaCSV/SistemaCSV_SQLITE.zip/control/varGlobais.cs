﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaCSV.control
{
    class varGlobais
    {
        public static string usuario;
        public static bool logado = false;
        public static string acesso;
        public static string limite_horas = "10:15:00";
        public static double valor_hora_extra = 30.00;
    }
}
